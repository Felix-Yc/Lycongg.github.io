var cookie = null;
var wid = null;


chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {
        // console.log(request);
		// console.log(sender);
        if(request.wid) {wid = request.wid;
		sendResponse("wid update is trigger!");};
        if(request.url){
        chrome.cookies.getAll({
            url: request.url
        }, (cks) => {
            cookie = cks.map((item) => {
                return item.name + "=" + item.value
            }).join(";") + ";";
        });
		sendResponse("cookie update is trigger!");
		};

        
    
		if(request.cmd == "feedback"){
			
			var headers = {
            'Connection': 'keep-alive',
            'Accept': '*/*',
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Origin': 'https://i.v.bsu.edu.cn',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://i.v.bsu.edu.cn/qfwapp/sys/lwBsuApplyForAdmission/*default/index.do?qrcode=6FCF03D1A3164A2E103EB9FF2BB88442',
            'User-Agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
            'cookie': cookie
            };
			
			var playload = {'WID': wid, 'CANCEL_STATUS': '已销假',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://i.v.bsu.edu.cn/qfwapp/sys/lwBsuApplyForAdmission/*default/index.do?qrcode=6FCF03D1A3164A2E103EB9FF2BB88442',
            'User-Agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
            'cookie': cookie};

            var datafg = false;

			$.ajax(
                {
                    url:'https://i.v.bsu.edu.cn/qfwapp/sys/lwBsuApplyForAdmission/modules/fdyxj/T_ADMINSSION_APPLICATION_MODIFY.do',
                    type:'post',
                    async:false,
                    data:playload,
                    // beforeSend: function(xhr) {
                    //     xhr.setRequestHeader('User-Agent',"Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",'Referer','https://i.v.bsu.edu.cn/qfwapp/sys/lwBsuApplyForAdmission/*default/index.do?qrcode=6FCF03D1A3164A2E103EB9FF2BB88442','cookie',cookie);
                    // },
					xhrFields: {
　　　　　　		withCredentials: true
　　　　			},
                    success:function(data){console.log(data);if(data.datas.T_ADMINSSION_APPLICATION_MODIFY == 1){console.log('success!');datafg = true};},
                    error:function(data){sendResponse("销假失败");}
                }
                );
                if(datafg){sendResponse("销假成功！");};
		
		}

	});





