
$(document).ready(function() {
    /* Manipulate DOM here */


    var a = $('#xiaojia');
    a.on('click', function() {
        chrome.runtime.sendMessage({ cmd: "feedback" }, function(response) {
        	console.log(response);
            if (response) {
                var div = document.getElementById("black");
                div.innerText = response;
				div.style.display = "block";
            };
        });

    });
	
	
	
	
	function getCurrentTabId(callback)
{
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs)
	{
		if(callback) callback(tabs.length ? tabs[0].id: null);
	});
}
	
	
	
	function sendMessageToContentScript(message, callback)
{
	getCurrentTabId((tabId) =>
	{
		chrome.tabs.sendMessage(tabId, message, function(response)
		{
			if(callback) callback(response);
		});
	});
}
	
	
	// var a = $('#run');
    // a.on('click', function() {

    	// alert('666!');

        // chrome.extension.sendMessage({ run: "run" }, function(response) {
        	// console.log(response);
            // if (response) {
                // var div = document.getElementById("black");
                // div.innerText = response;
            // };
        // });

    // });
	
	
	$('#run').click(() => {
	sendMessageToContentScript({cmd: "run" }, (response) => {
		if (response) {
			var div = document.getElementById("black");
			div.innerText = response;
			div.style.display = "block";
		};
	});
});
	
	

});