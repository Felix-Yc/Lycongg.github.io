function random(lower, upper) {
    return Math.floor(Math.random() * (upper - lower)) + lower;
}
var body = document.getElementsByTagName("body")[0];
document.onclick = function(e) {
    var num = random(0, 19);

    var color = ["peru", "goldenrod", "yellow",
        "chartreuse", "palevioletred", "deeppink",
        "pink", "palegreen", "plum",
        "darkorange", "powderblue", "orangered",
        "orange", "orchid", "red",
        "aqua", "salmon", "gold", "lawngreen"
    ]

    var divmain = document.createElement("div");
    var first = document.createElement("div");
    var second = document.createElement("div");

    divmain.setAttribute("id", "love");
    divmain.setAttribute("class", "love");
    first.setAttribute("id", "first");
    second.setAttribute("id", "second");

    divmain.appendChild(first);
    divmain.appendChild(second);

    divmain.style.cssText = "top:" + e.pageY + "px;left:" + e.pageX + "px";


    first.style.backgroundColor = color[num];
    second.style.backgroundColor = color[num];
    body.appendChild(divmain);

    $(".love").animate({
        opacity: "0",
        top: "-=50px"
    }, 1500);

}


setInterval(function() {
    var div = document.getElementsByClassName("love");
    var len = div.length;
    var num;
    for(var i = len - 1; i >= 0; i--) {
        num = parseInt(div[i].style.opacity);
        if(num <= 0) {
            div[i].remove();
        }
    }

}, 3500);