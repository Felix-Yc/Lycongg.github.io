
// window.addEventListener("load", myMain, false);
document.addEventListener('DOMContentLoaded', function()
{
	
});	
	
	




	function getCookies(url) {
	  chrome.runtime.sendMessage({url: url}, async function (response) {
		console.log(response);
	  });
	};
	


	function myMain() {
		console.log("content script is running!");
		getCookies(document.URL);
		
        var wid_line = document.getElementById('row0emapdatatable').getElementsByTagName('td')[0].getElementsByTagName('a')[0];	  
		console.log(wid_line);
		var wid = wid_line.getAttribute('data-wid');
		console.log(wid);
		chrome.runtime.sendMessage({wid: wid}, async function (response) {
		console.log(response);
	  });
	  
	};
	

	

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	console.log('收到来自 ' + (sender.tab ? "content-script(" + sender.tab.url + ")" : "popup或者background") + ' 的消息：', request);
	if(request.cmd == 'run') {
		console.log("content script is running!");
		getCookies(document.URL);
		
		var wid_line = document.getElementById('row0emapdatatable').getElementsByTagName('td')[0].getElementsByTagName('a')[0];	  
		// console.log(wid_line);
		var wid = wid_line.getAttribute('data-wid');
		sendResponse("加载成功，现在可以销假了")
		// console.log(wid);
		chrome.runtime.sendMessage({wid: wid}, async function (response) {
		console.log(response);
		
		});
	
	}
	else {
		tip(JSON.stringify(request));
		sendResponse('我收到你的消息了：'+JSON.stringify(request));
	}
});


